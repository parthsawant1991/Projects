import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;

public class tsapp_proxy_tcp implements Runnable {

	Socket client_socket;
	int server_write_port;
	char write_protocol;
	private String message_to_client;
	private String message_from_server;

	tsapp_proxy_tcp(Socket client_socket, int write_port, char write_protocol) {

		this.client_socket = client_socket;
		this.server_write_port = write_port;
		this.write_protocol = write_protocol;

	}


	@Override
	public void run() {
		
		System.out.println("Starting tsapp_proxy_tcp with protocol "+write_protocol);
		

		System.out.println("Received TCP connection from :"
				+ client_socket.getInetAddress() + " on port "
				+ client_socket.getPort());

		BufferedReader br;
		PrintWriter pw = null;
		String message_from_client;
		String message_from_server = null;
		String message_to_client = null;

		try {

			br = new BufferedReader(new InputStreamReader(
					client_socket.getInputStream()));

			message_from_client = br.readLine();

			System.out.println(message_from_client);

			if (write_protocol == 't') {

				System.out.println("Writing to TCP Server");
				
				try {
//
//					Thread.sleep(1000);

					Socket proxy_client_socket = new Socket("localhost",
							server_write_port);

					if (proxy_client_socket.isConnected()) {

						System.out.println("TCP Client connected to "
								+ proxy_client_socket.getInetAddress() +

								" on port " + proxy_client_socket.getPort());

						PrintWriter client_out = new PrintWriter(
								proxy_client_socket.getOutputStream(), true);

						client_out.println(message_from_client);
						client_out.flush();

//						proxy_client_socket.close();
					}

					Thread.sleep(20);

					BufferedReader client_in = new BufferedReader(
							new InputStreamReader(
									proxy_client_socket.getInputStream()));

					while ((message_from_server = client_in.readLine()) != null) {

						System.out.println("Message From Server to proxy_tcp using tcp: \n"
								+ message_from_server);
						message_to_client = new String(message_from_server);

					}
					
//					message_to_client = new String(message_from_server);

					proxy_client_socket.close();
					
				} catch (Exception e) {
					System.out.println("write error from tcp");
					e.printStackTrace();
				}

			}

			else if (write_protocol == 'u') {

				System.out.println("Writing to UDP Server" + server_write_port);

				try {
//					Thread.sleep(1000);
					DatagramSocket proxy_udp_client_socket = new DatagramSocket();
					InetAddress server_ip = InetAddress.getByName("localhost");

					byte[] proxy_data_to_server = new byte[100];
					byte[] proxy_data_from_server = new byte[100];

					proxy_data_to_server = message_from_client.getBytes();

					DatagramPacket proxy_packet_to_server = new DatagramPacket(
							proxy_data_to_server, proxy_data_to_server.length,
							server_ip, server_write_port);

					proxy_data_from_server = new byte[100];
					DatagramPacket proxy_packet_from_server = new DatagramPacket(
							proxy_data_from_server,
							proxy_data_from_server.length);

					Thread.sleep(20);

					proxy_udp_client_socket.send(proxy_packet_to_server);

					proxy_udp_client_socket.receive(proxy_packet_from_server);

					message_from_server = new String(
							proxy_packet_from_server.getData());
					
					System.out.println("Message From Server to proxy_tcp using udp: \n"
							+ message_from_server);

					message_to_client = new String(message_from_server);

					System.out.println("Message from server" + message_from_server);
					proxy_udp_client_socket.close();

				} catch (Exception e) {

					System.out.println("Write error from udp");
					e.printStackTrace();
				}

			}

			pw = new PrintWriter(client_socket.getOutputStream(), true);
//
//			System.out.println("Sending: " + message_to_client);

//			pw.println(message_to_client);
			pw.println(message_to_client);
			pw.flush();

			client_socket.close();

		} catch (Exception e) {
			System.out.println("Connection Error at TCP Proxy");
			e.printStackTrace();
			try {
				client_socket.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

}
