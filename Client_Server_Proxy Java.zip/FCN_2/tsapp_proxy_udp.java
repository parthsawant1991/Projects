import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;




public class tsapp_proxy_udp implements Runnable {
	
	
	DatagramSocket server_socket;
	private String message_from_server;
	static int server_write_port;

	
	static char write_protocol;
	
	tsapp_proxy_udp(DatagramSocket server_socket,int write_port,char write_protocol){
		
		this.server_socket=server_socket;
		tsapp_proxy_udp.server_write_port=write_port;
		tsapp_proxy_udp.write_protocol=write_protocol;	
	}

	@SuppressWarnings("null")
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Starting tsapp_proxy_udp with protocol "+  write_protocol);
		
		
		while(true){
			String message_from_client;
			String message_from_server;
			
			byte[] data_from_client = new byte[100];
			byte[] data_to_client = new byte[100];
			
			DatagramPacket packet_from_client = new DatagramPacket(
					data_from_client, data_from_client.length);
			
			try{
				
				server_socket.receive(packet_from_client);
				System.out.println("Message from client received.");
				int client_port = packet_from_client.getPort();
				InetAddress client_ip = packet_from_client.getAddress();
				message_from_client = new String(packet_from_client.getData());

				if(write_protocol=='t'){
					System.out.println("Writing to TCP Server");
					
					try {

//						Thread.sleep(1000);

						Socket client_socket = new Socket("localhost", tsapp_proxy_udp.server_write_port);

						if (client_socket.isConnected()) {

							System.out.println("TCP Client connected to "
									+ client_socket.getInetAddress() +

									" on port " + client_socket.getPort());

							PrintWriter client_out = new PrintWriter(
									client_socket.getOutputStream(), true);

//							if (set_flag) {
//								message_to_server = new String(client_time + "&"
//										+ "mod " + "%" + user + "#" + pass + "@");
//							} else {
//								message_to_server = new String(client_time + "&");
//							}
//
							client_out.println(message_from_client);
							client_out.flush();

						}

						Thread.sleep(20);

						BufferedReader client_in = new BufferedReader(
								new InputStreamReader(client_socket.getInputStream()));

						while ((message_from_server = client_in.readLine()) != null) {

							System.out.println("Message From Server: \n"
									+ message_from_server);
							data_to_client = message_from_server.getBytes();
							
					
							

						}
						
//						System.out.println("Message From Server to proxy_udp using tcp: \n"
//								+ message_from_server);
						
					//	data_to_client = message_from_server.getBytes();
						
						client_socket.close();
				}
				catch(Exception e){
				
					
				}
					
	
				}
				else if(write_protocol=='u'){
					
					System.out.println("Writing to UDP Server");
					try {
//						Thread.sleep(1000);
						DatagramSocket proxy_udp_client_socket = new DatagramSocket();
						InetAddress server_ip = InetAddress.getByName("localhost");

//						// message_to_server = new String(client_time);
//
//						if (set_flag) {
//							message_to_server = new String(client_time + "&" + "mod "
//									+ "%" + user + "#" + pass + "@");
//						} else {
//							message_to_server = new String(client_time + "&");
//						}

						byte[] proxy_data_to_server = new byte[100];
						byte[] proxy_data_from_server = new byte[100];

//						byte[] data_to_server = message_to_server.getBytes();

						proxy_data_to_server = message_from_client.getBytes();

						DatagramPacket proxy_packet_to_server = new DatagramPacket(
								proxy_data_to_server, proxy_data_to_server.length, server_ip, tsapp_proxy_udp.server_write_port);

						proxy_data_from_server = new byte[100];
						DatagramPacket proxy_packet_from_server = new DatagramPacket(
								proxy_data_from_server, proxy_data_from_server.length);

						Thread.sleep(20);

						proxy_udp_client_socket.send(proxy_packet_to_server);

						proxy_udp_client_socket.receive(proxy_packet_from_server);

						message_from_server = new String(proxy_packet_from_server.getData());

						System.out.println("Message From Server to proxy_udp using udp: \n"
								+ message_from_server);
						
						data_to_client = message_from_server.getBytes();
						
						//						System.out
//								.println("From Server: " + message_from_server.trim());
//						System.out.println("RTT: " + (stop - start - 20));

						proxy_udp_client_socket.close();

					} catch (Exception e) {

					}
					
					
	
					
				}
				
				
				
				
			//	data_to_client = message_from_server.getBytes();
				
				DatagramPacket packet_to_client = new DatagramPacket(
						data_to_client, data_to_client.length, client_ip,
						client_port);
				server_socket.send(packet_to_client);
				System.out.println("Message to client sent.");	
				
				
				
				
				
				
				
			}
			catch(Exception e){
				
				System.out.println("Connection Error");
				e.printStackTrace();
				
			}
			
			

			
		}
		
		
		
		
	}
	
	
	

}
