import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * This class contains the implementation of UDP Server
 * 
 * 
 * @author Parth
 *
 */
public class Tsapp_Server implements Runnable {

	DatagramSocket server_socket;
	public static String time = "-1";
	static String client_time;

	Tsapp_Server(DatagramSocket server_socket, String time) {
		this.server_socket = server_socket;
		Tsapp_Server.time = time;
	}

	@Override
	public void run() {

		String message_from_client;
		String message_to_client;
		String my_time;
		String client_user;
		String client_pass;

		while (true) {
			byte[] data_from_client = new byte[100];
			byte[] data_to_client = new byte[100];

			DatagramPacket packet_from_client = new DatagramPacket(
					data_from_client, data_from_client.length);

			try {

				server_socket.receive(packet_from_client);
				System.out.println("Message from client received.");
				int client_port = packet_from_client.getPort();
				InetAddress client_ip = packet_from_client.getAddress();
				message_from_client = new String(packet_from_client.getData());

				System.out.println("From Client: " + message_from_client);

				my_time = new String(message_from_client.substring(0,
						message_from_client.indexOf("&")));

				System.out.println("Current Time: " + tsapp.get_time());

				if (message_from_client.contains("mod")) {
					client_user = new String(message_from_client.substring(
							message_from_client.indexOf("%") + 1,
							message_from_client.indexOf("#")));
					client_pass = new String(message_from_client.substring(
							message_from_client.indexOf("#") + 1,
							message_from_client.indexOf("@")));

					System.out.println("Client user: " + client_user
							+ " Client pass: " + client_pass);

					if (client_user.equals(tsapp.get_user())
							&& (client_pass.equals(tsapp.get_pass()))) {

						System.out.println("Authentication Successful");
						tsapp.set_time(my_time);
					}
					else{
						System.out.println("Authentication Failed");
					}
				}

				System.out.println("Time from client: ");
				System.out.println(my_time);

				message_to_client = tsapp.get_time();
				data_to_client = message_to_client.getBytes();
				DatagramPacket packet_to_client = new DatagramPacket(
						data_to_client, data_to_client.length, client_ip,
						client_port);
				server_socket.send(packet_to_client);
				System.out.println("Message to client sent.");

			} catch (Exception e) {
				System.out.println("Connection Error");
				e.printStackTrace();
			}

		}

	}
}
