import java.io.BufferedReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.InputStreamReader;

/**
 * This class contains the implementation of TCP Server.
 * 
 * 
 * @author Parth
 *
 */
public class Tsapp_Server_2 implements Runnable {

	Socket client_socket;

	Tsapp_Server_2(Socket client_socket) {
		this.client_socket = client_socket;
	}

	@Override
	public void run() {

		System.out.println("Received TCP connection from :"
				+ client_socket.getInetAddress() + " on port "
				+ client_socket.getPort());

		BufferedReader br;
		PrintWriter pw;
		String message_from_client;
		String message_to_client;
		String my_time;
		String client_user;
		String client_pass;

		try {
			br = new BufferedReader(new InputStreamReader(
					this.client_socket.getInputStream()));

			message_from_client = br.readLine();
			System.out.println("From Client: " + message_from_client);

			my_time = new String(message_from_client.substring(0,
					message_from_client.indexOf("&")));

//			client_user = new String(message_from_client.substring(
//					message_from_client.indexOf("%") + 1,
//					message_from_client.indexOf("#")));
//			client_pass = new String(message_from_client.substring(
//					message_from_client.indexOf("#") + 1,
//					message_from_client.indexOf("@")));

			System.out.println("Current Time: " + tsapp.get_time());

			if (message_from_client.contains("mod")) {
				client_user = new String(message_from_client.substring(
						message_from_client.indexOf("%") + 1,
						message_from_client.indexOf("#")));
				client_pass = new String(message_from_client.substring(
						message_from_client.indexOf("#") + 1,
						message_from_client.indexOf("@")));

				System.out.println("Client user: " + client_user
						+ " Client pass: " + client_pass);

				if (client_user.equals(tsapp.get_user())
						&& (client_pass.equals(tsapp.get_pass()))) {

					System.out.println("Authentication Successful");
					tsapp.set_time(my_time);
				}
				else{
					System.out.println("Authentication Failed");
				}
			}

			System.out.println("Time from client: ");
			System.out.println(my_time);
			pw = new PrintWriter(new OutputStreamWriter(
					this.client_socket.getOutputStream()));

			message_to_client = tsapp.get_time();

			pw.println(message_to_client);
			pw.flush();
			this.client_socket.close();

		} catch (Exception e) {
			System.out.println("Connection Error");
			e.printStackTrace();
			try {
				this.client_socket.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

}
