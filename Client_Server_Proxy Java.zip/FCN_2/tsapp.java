import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

/**
 * tsapp.java
 * 
 * This class contains the implementation of the time server application
 * 
 * @author Parth
 *
 */
public class tsapp {

	static char listen_protocol; // communication protocol for receiving
	static char write_protocol; // communication protocol for writing
	static int listen_port_tcp; // tcp receiving port number
	static int listen_port_udp; // udp receiving port number
	static char type; // host type client/server/proxy-server
	static String user = null; // user name
	static String pass = null; // password
	static String server_user;
	static String server_pass;
	static boolean set_credentials = false;
	// public static int time = 5; // time either for modification or retrieval
	private static String time = "5";
	static int query_count = 1;
	static int write_port;
	static boolean set_flag = false;
	static boolean time_format = false;

	static char proxy_write_protocol_tcp = 'u';
	static char proxy_write_protocol_udp = 'u';
	static int proxy_udp_write_port;
	static int proxy_tcp_write_port;
	static int proxy_listen_tcp_port;
	static int proxy_listen_udp_port;

	public synchronized static void set_time(String time) {

		tsapp.time = new String(time);

	}

	public synchronized static String get_time() {

		return tsapp.time;

	}

	public synchronized static void set_user(String user) {

		tsapp.server_user = new String(user);

	}

	public synchronized static void set_pass(String pass) {

		tsapp.server_pass = new String(pass);
	}

	public synchronized static String get_user() {

		return (tsapp.server_user);
	}

	public synchronized static String get_pass() {
		return (tsapp.server_pass);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 0;

		// listen_port_tcp = Integer.parseInt(args[args.length - 1]);
		// listen_port_udp = Integer.parseInt(args[args.length - 2]);
		write_protocol = 'u';

		while (i < args.length) {

			if (args[i].equals("localhost")) {
				System.out.println("Running On: Localhost");
			} else if (args[i].equals("-c")) {
				System.out.println("Client");
				type = 'c';
			} else if (args[i].equals("-s")) {
				System.out.println("Server");
				type = 's';

			} else if (args[i].equals("-p")) {
				System.out.println("Proxy");
				type = 'p';
			} else if (args[i].equals("-t")) {
				System.out.println("TCP Protocol");
				tsapp.proxy_write_protocol_tcp = 't';
				tsapp.proxy_write_protocol_udp = 't';
				write_protocol = 't';
			} else if (args[i].equals("-u")) {
				tsapp.proxy_write_protocol_tcp = 'u';
				tsapp.proxy_write_protocol_udp = 'u';

				System.out.println("UDP Protocol");
				write_protocol = 'u';
			} else if (args[i].equals("-n")) {
				query_count = Integer.parseInt(args[++i]);
			} else if (args[i].equals("-T")) {
				System.out.println("Time: ");
				// time = args[++i];
				tsapp.set_flag = true;
				tsapp.set_time(args[++i]);

				System.out.println(tsapp.set_flag);

				System.out.println(tsapp.get_time());
			} else if (args[i].equals("--proxy-udp")) {

				// tsapp.proxy_write_protocol = 'u';

				tsapp.proxy_udp_write_port = Integer.parseInt(args[++i]);

				System.out.println("UDP Proxy");

			} else if (args[i].equals("--proxy-tcp")) {

				// tsapp.proxy_write_protocol = 't';
				tsapp.proxy_tcp_write_port = Integer.parseInt(args[++i]);

				System.out.println("TCP Proxy");
			} else if (args[i].equals("--user")) {

				if (type == 's') {
					tsapp.set_credentials = true;
				}

				tsapp.user = new String(args[++i]);

				// System.out.println("Username: " + args[++i]);
			} else if (args[i].equals("--pass")) {

				tsapp.pass = new String(args[++i]);
				// System.out.println("Password: " + args[++i]);
			}
			else if (args[i].equals("-z")) {

				tsapp.time_format = true;
				
			}
			
			else {
				System.out.println("Port: " + args[i]);

			}
			i++;

		}

		if (type == 'c') {

			if (write_protocol == 't') {

				write_port = Integer.parseInt(args[args.length - 1]);
				start_tcp_client(write_port, query_count, tsapp.time,
						tsapp.user, tsapp.pass);
			} else {
				write_port = Integer.parseInt(args[args.length - 1]);
				start_udp_client(write_port, query_count, tsapp.time,
						tsapp.user, tsapp.pass);
			}

		}

		if (type == 's') {

			if (set_credentials) {

				System.out.println("Setting Credentials");
				tsapp.server_user = new String(tsapp.user);
				tsapp.server_pass = new String(tsapp.pass);

			}

			listen_port_udp = Integer.parseInt(args[args.length - 2]);
			listen_port_tcp = Integer.parseInt(args[args.length - 1]);

			start_udp_server(listen_port_udp);

			start_tcp_server(listen_port_tcp);

		}

		if (type == 'p') {


			listen_port_udp = Integer.parseInt(args[args.length - 2]);
			listen_port_tcp = Integer.parseInt(args[args.length - 1]);

			if (proxy_write_protocol_udp == 't') {

				start_proxy_udp(listen_port_udp, proxy_tcp_write_port,
						proxy_write_protocol_udp);

			} else {

				start_proxy_udp(listen_port_udp, proxy_udp_write_port,
						proxy_write_protocol_udp);
			}
			
			if (proxy_write_protocol_tcp == 't') {
				start_proxy_tcp(listen_port_tcp, proxy_tcp_write_port,
						proxy_write_protocol_tcp);

			} else {
				start_proxy_tcp(listen_port_tcp, proxy_udp_write_port,
						proxy_write_protocol_tcp);

			}

		
			}

			// start_proxy_udp(listen_port_udp, proxy_udp_write_port,
			// proxy_write_protocol_udp);
			//
			// start_proxy_tcp(listen_port_tcp, proxy_tcp_write_port,
			// proxy_write_protocol_tcp);

		}

	

	private static void start_proxy_udp(int listen_port_udp,
			int client_write_port, char client_write_protocol) {

		System.out.println("Starting UDP Proxy" + listen_port_udp);

		DatagramSocket server_socket = null;
		try {
			server_socket = new DatagramSocket(listen_port_udp);
			new Thread(new tsapp_proxy_udp(server_socket, client_write_port,
					client_write_protocol)).start();

		} catch (SocketException e) {
			System.out
					.println("Connection Error. Failed to create Proxy Server");
		}

	}

	@SuppressWarnings("resource")
	private static void start_proxy_tcp(int listen_port_tcp,
			int client_write_port, char client_write_protocol) {

		System.out.println("Starting TCP Proxy" + listen_port_tcp);

		try {
		ServerSocket server_socket = new ServerSocket(listen_port_tcp);

		while (true) {

			Socket proxy_server_socket = null;

				proxy_server_socket = server_socket.accept();

				new Thread(new tsapp_proxy_tcp(proxy_server_socket,
						client_write_port, client_write_protocol)).start();
			}
		
		}catch (Exception e) {

				System.out.println("Proxy Error");
				e.printStackTrace();
			}

		
	}

	private static void start_udp_server(int port) {

		System.out.println("Starting UDP Server");

		DatagramSocket server_socket = null;
		try {
			server_socket = new DatagramSocket(port);
			new Thread(new Tsapp_Server(server_socket, tsapp.get_time()))
					.start();

		} catch (SocketException e) {
			System.out.println("Connection Error. Failed to create Server");
		}

	}

	@SuppressWarnings({ "resource" })
	private static void start_tcp_server(int port) {

		System.out.println("Starting TCP Server");

		ServerSocket server_socket = null;
		try {
			server_socket = new ServerSocket(port);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		while (true) {
			Socket time_server = null;
			try {
				time_server = server_socket.accept();
			} catch (IOException e) {

			}
			new Thread(new Tsapp_Server_2(time_server)).start();

		}

	}

	private static void start_udp_client(int port, int query_count,
			String client_time, String user, String pass) {

		String message_to_server;
		String message_from_server;
		byte[] data_to_server;
		byte[] data_from_server;

		while (query_count > 0) {
			System.out.println("Queries remaining " + query_count);

			try {
				Thread.sleep(1000);
				DatagramSocket udp_client_socket = new DatagramSocket();
				InetAddress server_ip = InetAddress.getByName("localhost");

				// message_to_server = new String(client_time);

				if (set_flag) {
					message_to_server = new String(client_time + "&" + "mod "
							+ "%" + user + "#" + pass + "@");
				} else {
					message_to_server = new String(client_time + "&");
				}

				data_to_server = new byte[100];

				data_to_server = message_to_server.getBytes();

				DatagramPacket packet_to_server = new DatagramPacket(
						data_to_server, data_to_server.length, server_ip, port);

				data_from_server = new byte[100];
				DatagramPacket packet_from_server = new DatagramPacket(
						data_from_server, data_from_server.length);

				long start = System.currentTimeMillis();

				Thread.sleep(20);

				udp_client_socket.send(packet_to_server);

				udp_client_socket.receive(packet_from_server);

				long stop = System.currentTimeMillis();

				message_from_server = new String(packet_from_server.getData());
				System.out
						.println("From Server: " + message_from_server.trim());
				if(tsapp.time_format){
					System.out.println(new java.util.Date(Integer.parseInt(message_from_server)));
					}
				
				System.out.println("RTT: " + (stop - start - 20));
				udp_client_socket.close();

			} catch (Exception e) {

			}
			query_count--;
		}

	}

	private static void start_tcp_client(int port, int query_count,
			String client_time, String user, String pass) {

		String message_to_server;
		String message_from_server;

		while (query_count > 0) {

			System.out.println("Queries remaining " + query_count);

			try {

				Thread.sleep(1000);

				Socket client_socket = new Socket("localhost", port);

				if (client_socket.isConnected()) {

					System.out.println("TCP Client connected to "
							+ client_socket.getInetAddress() +

							" on port " + client_socket.getPort());

					PrintWriter client_out = new PrintWriter(
							client_socket.getOutputStream(), true);

					if (set_flag) {
						message_to_server = new String(client_time + "&"
								+ "mod " + "%" + user + "#" + pass + "@");
					} else {
						message_to_server = new String(client_time + "&");
					}

					client_out.println(message_to_server);
					client_out.flush();

				}
				long start = System.currentTimeMillis();
				Thread.sleep(20);

				BufferedReader client_in = new BufferedReader(
						new InputStreamReader(client_socket.getInputStream()));
				long stop = 0;
				while ((message_from_server = client_in.readLine()) != null) {

					System.out.println("Message From Server: \n"
							+ message_from_server);
					if(tsapp.time_format){
					System.out.println(new java.util.Date(Integer.parseInt(message_from_server)));
				
					}
					
					stop = System.currentTimeMillis();

				}

				client_socket.close();

				System.out.println("RTT: " + (stop - start - 20));

			} catch (Exception e) {

			}

			query_count--;
		}

	}
}
