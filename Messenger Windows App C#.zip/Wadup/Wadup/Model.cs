﻿/// <summary>
/// Model.cs
/// @author Parth Sawant pss7278
/// </summary>


using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.Devices.Geolocation;

namespace Wadup
{

    /// <summary>
    /// This class contains teh implementation of our model
    /// </summary>
    class Model
    {

        public static string url = "http://www.cs.rit.edu/~jsb/2145/ProgSkills/Labs/Messenger/api.php?"; //server address
        public static string myEmail;  //current user's email
        public static string myPass;   //current user's password
        public static double myLat;     //current user's lattitude
        public static double myLong;    //current user's longitude
        public static string friendEmail;   //friend's email
        public static string friendName;    //friend's name
        public ObservableCollection<People> peopleList = new ObservableCollection<People>();    //collection of users
        public ObservableCollection<Conversations> myConversations = new ObservableCollection<Conversations>(); //collection of messages
        public static string errorMsg = "Network Error. Please Check your internet connection and try again.";
        public static string serverMsg = "Server Error. Cannot retrieve data from the server. Please try again.";
        public static bool navigate = false;

        /// <summary>
        /// This function is used to create an account at the server
        /// </summary>
        /// <param name="email"></param>
        /// <param name="pass"></param>
        /// <param name="fname"></param>
        /// <param name="lname"></param>
        /// <returns></returns>
        private async Task<string> createAccount(string email, string pass, string fname, string lname)
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "createAccount"),
                        new KeyValuePair<string, string>("email", email),
                        new KeyValuePair<string, string>("password", pass),
                        new KeyValuePair<string, string>("first_name", fname),
                        new KeyValuePair<string, string>("last_name", lname)
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function is used to delete an account from the server
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <param name="pass"></param>
        /// <returns></returns>
        private async Task<string> deleteAccount(string email, string pass)
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "deleteAccount"),
                        new KeyValuePair<string, string>("email", email),
                        new KeyValuePair<string, string>("password", pass),
                  };
                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                //response.EnsureSuccessStatusCode();
                return "Delete Successful";
            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function retrieves all the locations of the users from the server
        /// </summary>
        /// <returns></returns>
        public async Task<string> getLocations()
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "getLocations"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass)
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsStringAsync();
            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function retrieves all the messages sent to and by the current user, from the server
        /// </summary>
        /// <returns></returns>
        private async Task<string> getMessages()
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "getMessages"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass)
                    };
                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();

            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function retrieves a list of all the users
        /// </summary>
        /// <returns></returns>
        private async Task<string> getUsers()
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "getUsers"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass)
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function is used to send a message to another user
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public async Task<string> sendMessage(string msg)
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "sendMessage"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass),
                        new KeyValuePair<string, string>("to", friendEmail),
                        new KeyValuePair<string, string>("message", msg)
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsStringAsync();

            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
                return "Network Error";
            }
        }


        /// <summary>
        /// This function is used to set the location of current user
        /// </summary>
        /// <param name="newLat"></param>
        /// <param name="newLong"></param>
        /// <returns></returns>
        private async Task setLocation(double newLat, double newLong)
        {
            try
            {

                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "setLocation"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass),
                        new KeyValuePair<string, string>("lat", newLat.ToString()),
                        new KeyValuePair<string, string>("long", newLong.ToString()),
                        new KeyValuePair<string, string>("acc", "5")
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();
                await response.Content.ReadAsStringAsync();

            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            { }

        }


        /// <summary>
        /// This function is used for Push notifications
        /// </summary>
        /// <returns></returns>
        private async Task setPush()
        {
            try
            {
                var client = new HttpClient();
                var myString = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("command", "setPush"),
                        new KeyValuePair<string, string>("email", myEmail),
                        new KeyValuePair<string, string>("password", myPass),
                        new KeyValuePair<string, string>("pushUrl", ""),
                    };

                client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
                HttpResponseMessage response = await client.PostAsync(url, new FormUrlEncodedContent(myString));
                response.EnsureSuccessStatusCode();
                await response.Content.ReadAsStringAsync();

            }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
            {
            }
        }



        /// <summary>
        /// This function creates a new user account
        /// </summary>
        /// <param name="email"></param>
        /// <param name="pass"></param>
        /// <param name="fname"></param>
        /// <param name="lname"></param>
        /// <returns></returns>
        public async Task<string> signUp(string email, string pass, string fname, string lname)
        {
            if (checkAccount(email, pass, fname, lname))
            {
                var result = await createAccount(email, pass, fname, lname);

                if (result.ToString().Equals("Network Error"))
                {
                    return errorMsg;
                }
                else if (result.ToString().Equals("Account already exists"))
                {
                    return "Account already exists";
                }
                else if (result.ToString().Equals("Account Created"))
                {
                    return "Account created successfully";
                }
                else
                {
                    return "There was an error. Please try again.";
                }
            }
            else
            {
                return "Please Enter Your Sign Up Information Correctly";
            }
        }


       /// <summary>
       /// This function validates the input entered by the user
       /// </summary>
       /// <param name="email"></param>
       /// <param name="pass"></param>
       /// <param name="fname"></param>
       /// <param name="lname"></param>
       /// <returns></returns>
        private Boolean checkAccount(string email, string pass, string fname, string lname)
        {
            if (email.Trim() == "")
            {
                return false;
            }
            if (pass.Trim() == "")
            {
                return false;
            }
            if (fname.Trim() == "")
            {
                return false;
            }
            if (lname.Trim() == "")
            {
                return false;
            }
            return true;
        }



        /// <summary>
        /// This function is used to delete a user account
        /// </summary>
        /// <param name="email"></param>
        /// <param name="pass"></param>
        /// <returns></returns>
        public string delete(string email, string pass)
        {

            var result = deleteAccount(email, pass);

            if (result.ToString().Equals("Network Error"))
            {
                return errorMsg;
            }

            else if (result.ToString().Equals("Delete Successful"))
            {
                return "Delete Successful";
            }
            else
            {
                return "Delete Successful";
            }
        }

        internal object delete(string text1, string password, object text2, object text3)
        {
            throw new NotImplementedException();
        }




        /// <summary>
        /// This function is used to login a user to their account at server.
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<string> login(string email, string password)
        {
            if (checkLogin(email, password))
            {
                myEmail = email;
                myPass = password;

                var result = await getUsers();

                if (result.ToString().Equals("Network Error"))
                {
                    return errorMsg;
                }
                else if (result.ToString().Equals("Invalid user"))
                {
                    return "Invalid Credentials";
                }
                else
                {
                    await setLocation(43.102753, -77.632409);
                    return "Login successful";
                }

            }
            else
            {
                return "Please Enter Your Login Information Correctly";
            }
        }



        /// <summary>
        /// This function is used to validate the input by the user 
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private Boolean checkLogin(string email, string password)
        {
            if (email.Trim() == "")
            {
                return false;
            }
            if (password.Trim() == "")
            {
                return false;
            }
            return true;
        }



        /// <summary>
        /// This function lists all the users after retrieving them from the server
        /// </summary>
        /// <returns></returns>
        public async Task<string> getPeople()
        {
            var result = await getUsers();

            if (result.ToString().Equals("Network Error"))
            {
                return errorMsg;
            }
            else
            {
                try
                {
                    var objects = JArray.Parse(result);

                    foreach (JObject root in objects)
                    {
                        if (root["email"].ToString() != myEmail)
                        {
                            People temp = new People(root["first_name"].ToString() + " " + root["last_name"].ToString(), root["email"].ToString());
                            peopleList.Add(temp);
                        }
                    }
                }

#pragma warning disable CS0168
            catch (Exception e1)
#pragma warning restore CS0168
                {
                    return serverMsg;
                }
            }
            return "No Error";
        }



        /// <summary>
        /// This function checks and updates the location after login if null
        /// </summary>
        /// <returns></returns>
        public async Task checkLocation()
        {
            var result = await getLocations();

            if (result.ToString() != "Network Error")
            {

                var objects = JArray.Parse(result);
                try
                {
                    Geolocator myGeolocator = new Geolocator();
                    Geoposition myGeoposition = await myGeolocator.GetGeopositionAsync();
                    Geocoordinate myGeocoordinate = myGeoposition.Coordinate;

                    foreach (JObject root in objects)
                    {
                        if (root["email"].ToString().Equals(myEmail))
                        {
                            if ((root["latitude"].ToString() == "") || root["longitude"].ToString() == "")
                            {
                                await setLocation(43.102753, -77.632409);
                                // await setLocation(myGeocoordinate.Point.Position.Latitude, myGeocoordinate.Point.Position.Longitude);
                                return;
                            }

                            myLat = Convert.ToDouble(root["latitude"].ToString());
                            myLong = Convert.ToDouble(root["longitude"].ToString());
                            break;
                        }
                    }

                    if ((myLat != myGeocoordinate.Point.Position.Latitude) || (myLong != myGeocoordinate.Point.Position.Longitude))
                    {
                        await setLocation(myGeocoordinate.Point.Position.Latitude, myGeocoordinate.Point.Position.Longitude);
                        return;
                    }
                }

#pragma warning disable CS0168
                catch (Exception e1)
#pragma warning restore CS0168
                {
                }
            }
        }



        /// <summary>
        /// This function is used to display the conversation between users
        /// </summary>
        /// <returns></returns>
        public async Task<string> displayMessages()
        {
            var result = await getMessages();

            if (result.ToString().Equals("Network Error"))
            {
                return errorMsg;
            }
            else
            {
                try
                {
                    var objects = JArray.Parse(result);
                    myConversations.Clear();

                    foreach (JObject root in objects)
                    {
                        if (root["email"].ToString().Equals(friendEmail))
                        {
                            Conversations temp = new Conversations(root["message"].ToString());
                            Conversations ts = new Conversations(root["ts"].ToString());

                            if (root["msg_type"].ToString() == "to")
                            {
                                temp.align = "Right";
                                ts.align = "Right";
                            }
                            else
                            {
                                temp.align = "Left";
                                ts.align = "Left";
                            }

                            temp.fontSize = 22;
                            ts.fontSize = 15;

                            myConversations.Insert(0, ts);
                            myConversations.Insert(0, temp);
                        }
                    }
                }

#pragma warning disable CS0168
                catch (Exception e1)
#pragma warning restore CS0168
                {
                    return serverMsg;
                }
            }
            return "No Error";
        }

    }
}
