﻿/// <summary>
/// Menu.xaml.cs
/// @author Parth Sawant pss7278
/// </summary>


using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Maps;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Wadup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Menu : Page
    {

        Model mod = new Model();
        private Rectangle fence;
        private BasicGeoposition fencePosition;
        private Geopoint point;
        BitmapImage img;
        public Menu()
        {
            this.InitializeComponent();
        }

        async void HardwareButtons_BackPressed(object sender, Windows.Phone.UI.Input.BackPressedEventArgs e)
        {
            e.Handled = true;
            Windows.Phone.UI.Input.HardwareButtons.BackPressed -= HardwareButtons_BackPressed;
            if (Model.navigate == false)
            {
                var dialog = new MessageDialog("Logging Out");
                await dialog.ShowAsync();
                this.Frame.Navigate(typeof(Main));
            }
           
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {      
            performer();
            peopleList.ItemsSource = mod.peopleList;
            await mod.checkLocation();
            this.InitializeComponent();
            Model.navigate = false;
            Windows.Phone.UI.Input.HardwareButtons.BackPressed += HardwareButtons_BackPressed;
        }


        private async void delete(object sender, RoutedEventArgs e)
        {
            var message = mod.delete(delEmail.Text, delPass.Password);
            var dialog = new MessageDialog(message.ToString());


            if (message.ToString().Equals("Delete Successful"))
            {
                dialog.Commands.Add(new UICommand("Close", new UICommandInvokedHandler(this.myCommandHandler)));
            }

            await dialog.ShowAsync();
            this.Frame.Navigate(typeof(Main));

        }

        private void myCommandHandler(IUICommand command)
        {
            MenuPivot.SelectedIndex = 0;
        }

        private async void performer()
        {
            //string message = "";
            var ppl = await mod.getPeople();

            if (ppl.ToString() != "No Error")
            {
                var dialog = new MessageDialog(ppl.ToString());
                await dialog.ShowAsync();
                this.Frame.Navigate(typeof(Menu));
            }
        }


        /// <summary>
        /// This function describes what to do on map load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void myMap_OnLoaded(object sender, RoutedEventArgs e)
        {

            myMap.Center = new Geopoint(new BasicGeoposition() { Altitude = 643, Latitude = 43.089863, Longitude = -77.669609 });
            myMap.ZoomLevel = 13;

            var getData = await mod.getLocations();

            var objects = JArray.Parse(getData);

            foreach (JObject root in objects)
            {
                try
                {
                    double userLat = Convert.ToDouble(root["latitude"].ToString());
                    double userLong = Convert.ToDouble(root["longitude"].ToString());
                    string lastUpdated = root["lastUpdated"].ToString();

                    if ((userLat > -90) && (userLat < 90) && (userLong > -180) && (userLong < 180) && !lastUpdated.Equals("0000-00-00 00:00:00"))
                    {
                        fencePosition = new BasicGeoposition() { Latitude = Convert.ToDouble(root["latitude"].ToString()), Longitude = Convert.ToDouble(root["longitude"].ToString()) };
                        point = new Geopoint(fencePosition);

                        fence = new Rectangle();
                        fence.Name = root["first_name"].ToString() + " " + root["last_name"].ToString() + "\n" + "Last Updated: " + root["lastUpdated"].ToString();

                        fence.Width = 30;
                        fence.Height = 30;

                        img = new BitmapImage(new Uri("ms-appx:///Assets/Mark.png"));

                        fence.Fill = new ImageBrush() { ImageSource = img };
                        MapControl.SetLocation(fence, point);
                        MapControl.SetNormalizedAnchorPoint(fence, new Point(1.0, 0.5));

                        myMap.Children.Add(fence);
                        Model.friendEmail = root["email"].ToString();
                        fence.AddHandler(UIElement.TappedEvent, new TappedEventHandler(myMap_Tapped), true);
                    }
                }
#pragma warning disable CS0168
                catch (Exception e1)
#pragma warning restore CS0168
                { 
                continue;
                }
            }
        }


        /// <summary>
        /// This function defines what happens on tapping on the map
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void myMap_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Rectangle temp = (Rectangle)sender;         
            int i = temp.Name.IndexOf("Last Updated");
            string s = temp.Name.Substring(0,i);
            Model.friendName = s;
            MessageDialog myDialog = new MessageDialog(temp.Name);
            myDialog.Commands.Add(new UICommand("Message", new UICommandInvokedHandler(this.myCommandHandlerMessage)));
            myDialog.Commands.Add(new UICommand("Close", new UICommandInvokedHandler(this.myCommandHandlerClose)));
            await myDialog.ShowAsync();
            }


        /// <summary>
        /// This function defines what happens when a list item is tapped
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ListBoxItem_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ListBoxItem temp = (ListBoxItem)sender;
            Model.friendName = temp.Content.ToString();
            Model.friendEmail = temp.Tag.ToString();
     
            this.Frame.Navigate(typeof(ConversationWindow));
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        private void myCommandHandlerClose(IUICommand command)
        {
        }


        /// <summary>
        ///  
        /// </summary>
        /// <param name="command"></param>
        private void myCommandHandlerMessage(IUICommand command)
        {

            this.Frame.Navigate(typeof(ConversationWindow));
        }


    }
}
