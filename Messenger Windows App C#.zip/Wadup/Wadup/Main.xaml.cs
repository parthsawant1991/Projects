﻿/// <summary>
/// Main.xaml.cs
/// @author Parth Sawant pss7278
/// </summary>

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Wadup
{
    /// <summary>
    /// This class contains the implementation of the main page
    /// </summary>
    public sealed partial class Main : Page
    {

        Model mod = new Model();
        public Main()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Required;
        }



        /// <summary>
        /// This function defines what to do when navigated to this page
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

            this.InitializeComponent();

        }



        /// <summary>
        /// This function is used to sign up a user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void signup(object sender, RoutedEventArgs e)
        {
            var message = await mod.signUp(signEmail.Text, signPass.Password, signFName.Text, signLName.Text);
            var msgDialog = new MessageDialog(message.ToString());


            if (message.ToString().Equals("Account created successfully"))
            {
                msgDialog.Commands.Add(new UICommand("Close", new UICommandInvokedHandler(this.myCommandHandler)));
            }

            await msgDialog.ShowAsync();

        }



        /// <summary>
        /// This function is used to login a user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void login(object sender, RoutedEventArgs e)
        {
            var message = await mod.login(loginEmail.Text, loginPass.Password);
            if (message.ToString().Equals("Login successful"))
            {
             //   Windows.Phone.UI.Input.HardwareButtons.BackPressed += HardwareButtons_BackPressed;

                this.Frame.Navigate(typeof(Menu));
            }
            else
            {
                var msgDialog = new MessageDialog(message.ToString());
                await msgDialog.ShowAsync();
            }
        }


        /// <summary>
        /// User defined event handler
        /// </summary>
        /// <param name="command">(ignored)</param>
        private void myCommandHandler(IUICommand command)
        {
            MainPivot.SelectedIndex = 0;
        }
    }
}
