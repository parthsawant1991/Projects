﻿/// <summary>
/// People.cs
/// @author Parth Sawant pss7278
/// </summary>




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wadup
{

    /// <summary>
    /// This class contains the implementation of users
    /// </summary>
    class People
    {
        
        public string userName { get; set; } //User Full Name

       
        public string userEmail { get; set; }  //User email

        /// <summary>
        /// Parameterized constructor.
        /// </summary>
        /// <param name="_userName">Name to be initialized</param>
        /// <param name="_userEmail">Email to be initialized</param>
        public People(string _userName, string _userEmail)
        {
            this.userName = _userName;
            this.userEmail = _userEmail;
        }
    }
}
