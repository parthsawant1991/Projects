﻿/// <summary>
/// Conversations.cs
/// @author Parth Sawant pss7278
/// </summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wadup
{

    /// <summary>
    /// This class contains the implementation of the message
    /// </summary>
    class Conversations
    {
        public string msg { get; set; }
        public string align { get; set; }
        public int fontSize { get; set; }

        /// <summary>
        /// Parameterized constructor for initializing the values
        /// </summary>
        /// <param name="_msg">message to be initialized</param>
        public Conversations(string _msg)
        {
            this.msg = _msg;
        }
    }
}
