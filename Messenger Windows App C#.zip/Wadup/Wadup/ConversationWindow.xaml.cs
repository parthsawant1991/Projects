﻿/// <summary>
/// ConversationWindow.xaml.cs
/// @author Parth Sawant pss7278
/// </summary>


using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Wadup
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ConversationWindow : Page
    {

        Model mod = new Model();
        int oldMessages;

        DispatcherTimer myTimer;

        public ConversationWindow()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Model.navigate = true;
            oldMessages = convList.Items.Count;
            ChatPageHeader.Text = Model.friendName;
            chatInitializer();
            convList.ItemsSource = mod.myConversations;
            myTimer = new DispatcherTimer();
            myTimer.Interval = new TimeSpan(0, 0, 2);
            myTimer.Tick += myTimer_Tick;
            myTimer.Start();
            Windows.Phone.UI.Input.HardwareButtons.BackPressed += HardwareButtons_BackPressed;

        }

        private async void chatInitializer()
        {
            var temp = await mod.displayMessages();

            if (temp.ToString() != "No Error")
            {
                var dialog = new MessageDialog(temp.ToString());
                await dialog.ShowAsync();
                myTimer.Stop();
            }

        }


        void HardwareButtons_BackPressed(object sender, Windows.Phone.UI.Input.BackPressedEventArgs e)
        {
            e.Handled = true;
            Windows.Phone.UI.Input.HardwareButtons.BackPressed -= HardwareButtons_BackPressed;
            myTimer.Stop();
            this.Frame.Navigate(typeof(Menu));
        }

        void myTimer_Tick(object sender, object e)
        {
            chatInitializer();

            if (oldMessages < convList.Items.Count)
            {
                oldMessages = convList.Items.Count;
                convList.ScrollIntoView(convList.Items[convList.Items.Count - 1]);
            }
        }

        private async void btnSend_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (txtMessage.Text.Trim() != "")
            {
                string s = await mod.sendMessage(txtMessage.Text);
                txtMessage.Text = "";
            }
        }

    }
}
