
import java.io.Serializable;

/**
 * This class contains the implementation of our tcp packet.
 * @author Parth
 *
 */
public class tcp_packet implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int sequence; //sequence number of the packet
	public boolean ack_flag; //acknowledgement flag 
	public byte[] data;// payload data to be transported
	public long checksum; //checksum of the payload data
	public boolean eom; //end of message flag to denote end of transmission.
	
	public tcp_packet(){
		
		data = new byte[500];
		eom = false;
		sequence = 0;
		ack_flag = false;
		checksum = 0;
	}
}
