import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;
import java.util.zip.CRC32;

/**
 * This class contains the client implementation of the fcntcp applicataion. The
 * client is responsible for the transmission of a file to the server.
 * 
 * @author Parth
 *
 */
public class Client {
	private static int cwnd = 1;
	private static int current_ack = 0;
	public static int duplicate_count = 0;
	private static int pack = 0;
	public static byte[] data_to_server = new byte[1024];
	public static byte[] data_from_server = new byte[1024];
	public static String message_from_server;
	public double ssthresh = 3;
	public static boolean packet_drop = false;
	public static InetAddress IPAddress;
	public static int port;
	public static long RTT = 1000;
	public ArrayList<Integer> ack_collection = new ArrayList<Integer>();
	public static ArrayList<tcp_packet> tcp_segment;
	public int rwnd = 15;

	/**
	 * This method is responsible for the beginning of the client execution.
	 */
	public void start_client() {

		File file = new File(fcntcp.file_name);
		tcp_segment = new ArrayList<tcp_packet>();
		generate_packets(tcp_segment, file);
		System.out.println("Segment size " + tcp_segment.size());
		Client tcp_client = new Client();
		Client_Transmit tcp_client_transmit = tcp_client.new Client_Transmit();
		tcp_client_transmit.start();
		try {
			tcp_client_transmit.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method accepts a file and a collection object as input and fills the
	 * collection object with packets generated from the file.
	 * 
	 * @param tcp_segment
	 * @param file
	 */
	public void generate_packets(ArrayList<tcp_packet> tcp_segment, File file) {
		tcp_packet packet;
		Scanner sc = null;
		try {
			sc = new Scanner(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StringBuffer str_buffer = new StringBuffer();
		while (sc.hasNext()) {
			str_buffer.append(sc.next() + " ");
		}
		str_buffer.trimToSize();
		System.out.println(str_buffer.capacity());
		String buffer = str_buffer.toString();

		byte[] byte_data = buffer.getBytes();

		CRC32 chksum = new CRC32();

		int counter = 0;
		for (int i = 0; i < byte_data.length - 500 + 1; i += 500) {
			packet = new tcp_packet();
			packet.data = Arrays.copyOfRange(byte_data, i, i + 500);
			chksum.update(packet.data, 0, packet.data.length);
			long value1 = chksum.getValue();
			packet.checksum = value1;
			// packet.offset = 500 * (counter + 1);
			packet.sequence = counter;
			tcp_segment.add(packet);
			counter++;

		}

		if (byte_data.length % 500 != 0) {
			packet = new tcp_packet();
			packet.data = Arrays.copyOfRange(byte_data, byte_data.length
					- byte_data.length % 500, byte_data.length);
			chksum.update(packet.data, 0, packet.data.length);
			long value1 = chksum.getValue();
			packet.checksum = value1;
			// packet.offset = byte_data.length;
			packet.sequence = counter;
			tcp_segment.add(packet);
		}
		tcp_segment.get(tcp_segment.size() - 1).eom = true;
	}

	/**
	 * This class is responsible for the transmission of packets to the server.
	 * 
	 * @author Parth
	 *
	 */
	public class Client_Transmit extends Thread {

		DatagramSocket client_socket;
		DatagramPacket dataPacket;
		Random random_obj = new Random();
		int random_int = random_obj.nextInt(9);

		public void run() {
			connect();
			send_to_server();
		}

		/**
		 * This method is used to establish a connection with the server using a
		 * three way handshaking mechanism.
		 */
		public synchronized void connect() {
			try {
				client_socket = new DatagramSocket();
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				IPAddress = InetAddress.getByName("localhost");
				port = fcntcp.port;
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			data_to_server = new String("SYN: " + random_int).getBytes();
			DatagramPacket sendPacket = new DatagramPacket(data_to_server,
					data_to_server.length, IPAddress, port);
			Client_Receive receive = new Client_Receive(client_socket);
			receive.start();
			try {
				client_socket.send(sendPacket);
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(RTT);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			int sync_no = Integer.parseInt(message_from_server
					.substring(message_from_server.indexOf(":") + 2));
			sync_no++;
			data_to_server = new String("ACK: " + sync_no).getBytes();
			sendPacket = new DatagramPacket(data_to_server,
					data_to_server.length, IPAddress, port);
			try {
				client_socket.send(sendPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/**
		 * This method is responsible for transmitting packets to the server
		 * using and object output stream.
		 */
		private void send_to_server() {
			while (pack != tcp_segment.size()) {

				try {
					client_socket = new DatagramSocket();
				} catch (SocketException e) {
					e.printStackTrace();
				}
				int i = 0;
				while (i < cwnd && pack < tcp_segment.size()) {
					ByteArrayOutputStream byte_out = new ByteArrayOutputStream();
					try {
						ObjectOutputStream object_out = new ObjectOutputStream(
								byte_out);
						object_out.writeObject(tcp_segment.get(pack));
						object_out.flush();
						byte[] bytes = byte_out.toByteArray();
						System.out.println("Sending: "
								+ new String(""
										+ tcp_segment.get(pack).sequence));
						pack++;
						dataPacket = new DatagramPacket(bytes, bytes.length,
								IPAddress, port);

						client_socket.send(dataPacket);
						i++;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				try {
					Thread.sleep(RTT);
					Collections.sort(ack_collection);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		/**
		 * this method is responsible for the retransmission of packets in case
		 * of failure.
		 * 
		 * @param pack
		 */
		public void retransmit(int pack) {
			try {
				client_socket = new DatagramSocket();
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				ByteArrayOutputStream byte_out = new ByteArrayOutputStream();
				ObjectOutputStream object_out = new ObjectOutputStream(byte_out);
				object_out.writeObject(tcp_segment.get(pack));
				object_out.flush();
				byte[] bytes = byte_out.toByteArray();
				System.out.println("Sending: "
						+ new String("" + tcp_segment.get(pack).sequence));
				pack++;
				dataPacket = new DatagramPacket(bytes, bytes.length, IPAddress,
						port);
				client_socket.send(dataPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * This class contains the implementation for the reception of packets from
	 * the server.
	 * 
	 * @author Parth
	 *
	 */
	public class Client_Receive extends Thread {
		DatagramSocket client_socket;
		DatagramPacket packet_from_server;

		public Client_Receive(DatagramSocket client_socket) {
			this.client_socket = client_socket;
		}

		public void run() {
			connect();
			try {
				Thread.sleep(RTT);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			receive_from_server();
		}

		/**
		 * This method is responsible for the connection establishment to the
		 * server.
		 */
		private synchronized void connect() {
			packet_from_server = new DatagramPacket(data_from_server,
					data_from_server.length);
			try {
				client_socket.receive(packet_from_server);
			} catch (IOException e) {
				e.printStackTrace();
			}
			message_from_server = new String(packet_from_server.getData())
					.trim();
			System.out.println(message_from_server);
		}

		/**
		 * This method is responsible for the reception of packets from the
		 * server.
		 */
		private void receive_from_server() {
			try {

				while (true) {
					packet_from_server = new DatagramPacket(data_from_server,
							data_from_server.length);

					client_socket.receive(packet_from_server);
					ByteArrayInputStream byte_in = new ByteArrayInputStream(
							packet_from_server.getData());
					ObjectInputStream object_in = new ObjectInputStream(byte_in);
					tcp_packet tcp_packet_from_server = (tcp_packet) object_in
							.readObject();
					System.out.println("Received ACK: "
							+ tcp_packet_from_server.sequence);

					if (ack_collection
							.contains(tcp_packet_from_server.sequence)) {

						cwnd = 1;
						System.out.println("cwnd updated to 1 ");
						duplicate_count++;
						current_ack = tcp_packet_from_server.sequence;

					}

					else {
						ack_collection.add(tcp_packet_from_server.sequence);

						if (packet_drop == false) {
							cwnd++;
							if (cwnd > rwnd) {
								cwnd = rwnd;
							}
							System.out.println("cwnd incremented to " + cwnd);
							if (cwnd > rwnd) {
								cwnd = rwnd;
							}

						} else {
							if (cwnd <= ssthresh) {

								cwnd += cwnd;
								if (cwnd > rwnd) {
									cwnd = rwnd;
								}
								System.out.println("cwnd incremented to "
										+ cwnd);
							}
							if (cwnd > ssthresh) {
								cwnd++;
								if (cwnd > rwnd) {
									cwnd = rwnd;
								}
								System.out.println("cwnd incremented to "
										+ cwnd);
							}
						}
					}

					if (duplicate_count == 3) { //in case of triplicate acknowledgements
						Client_Transmit s = new Client_Transmit();
						s.retransmit(current_ack);
						duplicate_count = 0;
						current_ack = 0;
						cwnd = 1;
						System.out.println("cwnd updated to 1");
						packet_drop = true;
					}

				}

			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

}
