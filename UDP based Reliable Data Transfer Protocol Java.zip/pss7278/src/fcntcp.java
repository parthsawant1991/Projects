

import java.net.DatagramSocket;

/**
 * This class contains the implementation of fcntcp application.
 * 
 * @author Parth
 *
 */
public class fcntcp {

	static char application_type;
	static String file_name = "mytext.txt";
	static int time_out = 1000;
	static boolean quite_mode = false;
	static String server_address;
	static int port;


/**
 * This method contains the main thread of execution for our fcntcp application
 * @param args
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 0;

		while (i < args.length) {

			if (args[i].equals("-c")) {
				application_type = 'c';
				System.out.println("Starting client ");
			} else if (args[i].equals("-s")) {
				application_type = 's';
				System.out.println("Starting server ");
			} else if (args[i].equals("-f")) {
				file_name = new String(args[++i]);
			} else if (args[i].equals("-t")) {
				time_out = Integer.parseInt(args[++i]);
				System.out.println("Setting timeout to " + time_out);
			} else if (args[i].equals("-q")) {
				quite_mode = true;
				System.out.println("Quite mode enabled ");
			} else {
				System.out.println(args[i]);
			}

			i++;
		}

		server_address = args[args.length - 2];
		port = Integer.parseInt(args[args.length - 1]);


		if (application_type == 'c') { // running in client mode

			start_tcp_client();

		} else if (application_type == 's') { //running in server mode

			start_tcp_server();

		} else {
			System.out.println("Incorrect arguments");
		}
	}


	/**
	 * This method is responsible for the starting of tcp server.
	 */
	private static void start_tcp_server() {
		// TODO Auto-generated method stub

			Server tcp_server = new Server();
			tcp_server.start_server();

	}


	/**
	 * This method is responsible for the starting of tcp client.
	 */
	private static void start_tcp_client() {
		// TODO Auto-generated method stub
		
		Client tcp_client = new Client();
		tcp_client.start_client();



	}

}
