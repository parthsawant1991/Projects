import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Random;
import java.util.TreeMap;
import java.util.zip.CRC32;

/**
 * This class contains the server implementation of the fcntcp application.
 * 
 * @author Parth
 *
 */
public class Server {
	public static byte[] data_from_client = new byte[1024];
	public static byte[] data_to_client = new byte[1024];
	public static InetAddress IPAddress;
	public static int port;
	public static int sync_no;
	public static int sequence_number = 0;
	static tcp_packet packet = new tcp_packet();
	public static boolean flag = false;
	public static TreeMap<Integer, String> segments = new TreeMap<Integer, String>();
	public ArrayList<Integer> ackList = new ArrayList<Integer>();
	public int random_int;

	/**
	 * This method is responsible for the execution of the server.
	 */
	public void start_server() {
		Server tcp_server = new Server();
		Server_Receive tcp_server_receive = tcp_server.new Server_Receive();
		tcp_server_receive.start();
	}

	/**
	 * This class contains the implementation of the server transmission
	 * mechanism.
	 * 
	 * @author Parth
	 *
	 */
	public class Server_Transmit extends Thread {
		DatagramSocket server_socket;
		DatagramPacket packet_to_client;

		public Server_Transmit(DatagramSocket server_socket) {
			this.server_socket = server_socket;
		}

		public void run() {
			connect();

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method is responsible for the connection establishment with the
		 * client.
		 */
		private synchronized void connect() {
			data_to_client = new String("ACK: " + sync_no).getBytes();
			packet_to_client = new DatagramPacket(data_to_client,
					data_to_client.length, IPAddress, port);
			try {
				server_socket.send(packet_to_client);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method is responsible for the transmission of acks to the
		 * client.
		 */
		private synchronized void send_to_client() {
			ByteArrayOutputStream byte_out = new ByteArrayOutputStream();
			try {
				ObjectOutputStream object_out = new ObjectOutputStream(byte_out);
				object_out.writeObject(packet);
				object_out.flush();
				byte[] bytes = byte_out.toByteArray();

				System.out.println("Sending ACK: " + packet.sequence);
				packet_to_client = new DatagramPacket(bytes, bytes.length,
						IPAddress, port);
				server_socket.send(packet_to_client);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * This class contains the implementation of the reception mechanism of the
	 * server.
	 * 
	 * @author Parth
	 *
	 */
	public class Server_Receive extends Thread {

		DatagramPacket packet_from_client;
		DatagramSocket server_socket;

		public void run() {
			Random random_obj = new Random();
			random_int = random_obj.nextInt(10);
			connect();
			receive_from_client();
		}

		/**
		 * This method is responsible for the connection establishment to the
		 * client.
		 */
		private synchronized void connect() {
			try {
				server_socket = new DatagramSocket(fcntcp.port);
			} catch (SocketException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

			while (true) {
				packet_from_client = new DatagramPacket(data_from_client,
						data_from_client.length);
				try {
					server_socket.receive(packet_from_client);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				String message_from_client = new String(
						packet_from_client.getData()).trim();
				System.out.println(message_from_client);

				IPAddress = packet_from_client.getAddress();
				port = packet_from_client.getPort();
				sync_no = Integer.parseInt(message_from_client
						.substring(message_from_client.indexOf(":") + 2));
				sync_no++;

				Server_Transmit send = new Server_Transmit(server_socket);
				send.start();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				packet_from_client = new DatagramPacket(data_from_client,
						data_from_client.length);
				try {
					server_socket.receive(packet_from_client);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				message_from_client = new String(packet_from_client.getData())
						.trim();
				System.out.println(message_from_client);

				break;
			}

		}

		/**
		 * This method is responsible for the reception of packets from the
		 * client.
		 */
		private synchronized void receive_from_client() {
			try {
				while (true) {
					packet_from_client = new DatagramPacket(data_from_client,
							data_from_client.length);
					server_socket.receive(packet_from_client);
					ByteArrayInputStream byte_in = new ByteArrayInputStream(
							packet_from_client.getData());
					ObjectInputStream object_in = new ObjectInputStream(byte_in);
					tcp_packet tcp_packet_from_client = (tcp_packet) object_in
							.readObject();
					if (flag == false
							&& (tcp_packet_from_client.sequence == random_int
									|| tcp_packet_from_client.sequence == (random_int + 1) || tcp_packet_from_client.sequence == (random_int + 2))) {
						packet.sequence = sequence_number;
						packet.ack_flag = true;
						System.out.println("From Client: "
								+ new String(""
										+ tcp_packet_from_client.sequence));

						System.out.println("Check Sum: "
								+ tcp_packet_from_client.checksum);

						segments.put(tcp_packet_from_client.sequence,
								new String(tcp_packet_from_client.data));
						if (tcp_packet_from_client.sequence == (random_int + 2)) {
							flag = true;
						}
					} else {
						if (flag == true) {
							flag = false;
						}
						sequence_number = tcp_packet_from_client.sequence + 1;
						packet.sequence = sequence_number;
						packet.ack_flag = true;
						System.out.println("From Client: "
								+ new String(""
										+ tcp_packet_from_client.sequence));
						System.out.println("Check Sum: "
								+ tcp_packet_from_client.checksum);

						CRC32 chksum = new CRC32();
						chksum.update(tcp_packet_from_client.data, 0,
								tcp_packet_from_client.data.length);
						long value1 = chksum.getValue();

						// System.out.println("Calculated Checksum of Packet: "
						// + value1);

						segments.put(tcp_packet_from_client.sequence,
								new String(tcp_packet_from_client.data));
					}

					Server_Transmit send = new Server_Transmit(server_socket);
					send.send_to_client();
					if (tcp_packet_from_client.eom) {
						File file = new File("Output.txt");
						FileWriter f_writer = new FileWriter(
								file.getAbsoluteFile());
						BufferedWriter b_writer = new BufferedWriter(f_writer);

						for (int i = 0; i < segments.size(); i++) {

							b_writer.write(segments.get(i));

						}
						b_writer.close();
						System.exit(1);
						
					}
				}
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

}