﻿
/**
 * Solution.cs
 * 
 * Contains the implementation of HashTable.
 *
 * Author: Parth Sawant pss7278
 * 
 * Test Authors: Parth Sawant pss7278
 *              
 *               
 */


using System;
using System.Collections.Generic;

namespace RIT_CS
{
    /// <summary>
    /// An exception used to indicate a problem with how
    /// a HashTable instance is being accessed
    /// </summary>
    public class NonExistentKey<Key> : Exception
    {
        /// <summary>
        /// The key that caused this exception to be raised
        /// </summary>
        public Key BadKey { get; private set; }

        /// <summary>
        /// Create a new instance and save the key that
        /// caused the problem.
        /// </summary>
        /// <param name="k">
        /// The key that was not found in the hash table
        /// </param>
        public NonExistentKey(Key k) :
            base("Non existent key in HashTable: " + k)
        {
            BadKey = k;
        }
    }

    /// <summary>
    /// An associative (key-value) data structure.
    /// A given key may not appear more than once in the table,
    /// but multiple keys may have the same value associated with them.
    /// Tables are assumed to be of limited size are expected to automatically
    /// expand if too many entries are put in them.
    /// </summary>
    /// <param name="Key">the types of the table's keys (uses Equals())</param>
    /// <param name="Value">the types of the table's values</param>
    interface Table<Key, Value> : IEnumerable<Key>
    {
        /// <summary>
        /// Add a new entry in the hash table. If an entry with the
        /// given key already exists, it is replaced without error.
        /// put() always succeeds.
        /// (Details left to implementing classes.)
        /// </summary>
        /// <param name="k">the key for the new or existing entry</param>
        /// <param name="v">the (new) value for the key</param>
        void Put(Key k, Value v);

        /// <summary>
        /// Does an entry with the given key exist?
        /// </summary>
        /// <param name="k">the key being sought</param>
        /// <returns>true iff the key exists in the table</returns>
        bool Contains(Key k);

        /// <summary>
        /// Fetch the value associated with the given key.
        /// </summary>
        /// <param name="k">The key to be looked up in the table</param>
        /// <returns>the value associated with the given key</returns>
        /// <exception cref="NonExistentKey">if Contains(key) is false</exception>
        Value Get(Key k);
    }

    class TableFactory
    {
        /// <summary>
        /// Create a Table.
        /// (The student is to put a line of code in this method corresponding to
        /// the name of the Table implementor s/he has designed.)
        /// </summary>
        /// <param name="K">the key type</param>
        /// <param name="V">the value type</param>
        /// <param name="capacity">The initial maximum size of the table</param>
        /// <param name="loadThreshold">
        /// The fraction of the table's capacity that when
        /// reached will cause a rebuild of the table to a 50% larger size
        /// </param>
        /// <returns>A new instance of Table</returns>
        public static Table<K, V> Make<K, V>(int capacity = 100, double loadThreshold = 0.75)
        {
            return new LinkedHashTable<K, V>(capacity, loadThreshold);
        }
    }

    class MainClass
    {
        public static void Main(string[] args)
        {
            Table<String, String> ht = TableFactory.Make<String, String>(4, 0.5);
            ht.Put("Joe", "Doe");
            ht.Put("Jane", "Brain");
            ht.Put("Chris", "Swiss");
            try
            {
                foreach (String first in ht)
                {
                    Console.WriteLine(first + " -> " + ht.Get(first));
                }
                Console.WriteLine("=========================");

                ht.Put("Wavy", "Gravy");
                ht.Put("Chris", "Bliss");
                foreach (String first in ht)
                {
                    Console.WriteLine(first + " -> " + ht.Get(first));
                }
                Console.WriteLine("=========================");

                Console.Write("Jane -> ");
                Console.WriteLine(ht.Get("Jane"));
                Console.Write("John -> ");
                Console.WriteLine(ht.Get("John"));
            }
            catch (NonExistentKey<String> nek)
            {
                Console.WriteLine(nek.Message);
                Console.WriteLine(nek.StackTrace);
            }

            TestTable.test();

            Console.ReadLine();
        }
    }

    /// <summary>
    /// A user defined class to store key value pairs
    /// </summary>
    /// <typeparam name="K">types of table's keys</typeparam>
    /// <typeparam name="V">types of table's values</typeparam>
    public class MyHashPair<K, V>
    {
        /// <summary>
        /// 
        /// </summary>
        private K key;

        private V value;

        public MyHashPair(K k, V v)
        {
            key = k;
            value = v;
        }

        public K getKey()
        {
            return key;
        }

        public V getValue()
        {
            return value;
        }

        public void setKey(K k)
        {
            key = k;
        }

        public void setValue(V v)
        {
            value = v;
        }
    }


    public class LinkedHashTable<Key, Value> : Table<Key, Value>
    {

        /// <summary>
        /// Store keys in an array of type MyHashPair
        /// </summary>
        List<MyHashPair<Key, Value>>[] myKeyList;

        /// <summary>
        /// Maximum capacity of the List.
        /// </summary>
        int capacity;

        /// <summary>
        /// Current population of elements in the List.
        /// </summary>
        int count;

        /// <summary>
        /// If the count goes above the given threshold value, then
        /// the capacity is increased by rehashing.
        /// </summary>
        double thresh;

        /// <summary>
        /// A constructor for LinkedHashTable.
        /// </summary>
        /// <param name="_capacity">Contains the maximum list size</param>
        /// <param name="_thresh">Contains the threshold value</param>
        public LinkedHashTable(int _capacity, double _thresh)
        {
            capacity = _capacity;
            count = 0;
            thresh = _thresh;
            myKeyList = new List<MyHashPair<Key, Value>>[capacity];
        }

        /// <summary>
        /// Adds the entry into the hash table
        /// </summary>
        /// <param name="k">key for the entry
        /// Adds a new entry into the hash tablery</param>
        /// <param name="v">value for the key</param>
        public void Put(Key k, Value v)
        {
            // flag to check for new entry
            bool chk = false;

            // To calculate the index in myKeylist
            int index = Math.Abs(k.GetHashCode()) % capacity;


            // If an index value is null, initialize it
            // else search whether an entry exists the key
            if (myKeyList[index] == null)
            {
                myKeyList[index] = new List<MyHashPair<Key, Value>>();
            }
            
            else
            {
                foreach (MyHashPair<Key, Value> tempKey in myKeyList[index])
                {
                    // check for duplicates
                    if (tempKey.getKey().Equals(k))
                    {
                        // if yes, set flag to true and set new value to the key
                        chk = true;
                        tempKey.setValue(v);
                        break;
                    }
                }
            }

            // if no duplicate keys,
            // create a new entry for the given key
            if (chk != true)
            {
                myKeyList[index].Add(new MyHashPair<Key, Value>(k, v));

                // increment the count for new insertion
                count++;

                // Check threshold value against count
                if (count > thresh * capacity)
                    rehash();
            }
        }

        /// <summary>
        /// Expands the list if the count exceeds the threshold value
        /// </summary>
        public void rehash()
        {
            // Temporary container to store all the key-value pairs
            List<MyHashPair<Key, Value>> buffer = new List<MyHashPair<Key, Value>>();

            // Temporary variable to store the count
            int bufferSize = count;

            // Store the key-value pairs in the temporary container
            for (int i = 0; i < capacity; i++)
            {
                if (myKeyList[i] != null)
                {
                    foreach (MyHashPair<Key, Value> temp in myKeyList[i])
                    {
                        buffer.Add(new MyHashPair<Key, Value>(temp.getKey(), temp.getValue()));
                    }
                }
            }

            // Increase the capacity by 50%
            capacity += (capacity / 2);

            myKeyList = new List<MyHashPair<Key, Value>>[capacity];

            // Initialize count as zero
            count = 0;

            // Transfer back key-value pairs to myKeyList
            for (int i = 0; i < bufferSize; i++)
            {
                Put(buffer[i].getKey(), buffer[i].getValue());
            }
        }

        /// <summary>
        /// Returns the respective value for the key
        /// </summary>
        /// <param name="k">key
        /// </param>
        /// <returns>value for the key
        /// </returns>
        public Value Get(Key k)
        {
            // Calculate the location 
            int index = Math.Abs(k.GetHashCode()) % capacity;


            // For a null index ie. no entry for key,
            // throw corresponding non existent key error
            // else search whether a value exists for that key
            if (myKeyList[index] == null)
                throw new NonExistentKey<Key>(k);
            
            else
            {
                foreach (MyHashPair<Key, Value> temp in myKeyList[index])
                {
                    if (temp.getKey().Equals(k))
                        // if present then return value
                        return temp.getValue();
                }
                throw new NonExistentKey<Key>(k);
            }
        }

        /// <summary>
        /// Checks whether the key exists
        /// </summary>
        /// <param name="k">key for the existing entry
        /// </param>
        /// <returns>true if key exists else false
        /// </returns>
        public bool Contains(Key k)
        {

            // To calculate the location in myKeyList
            int index = Math.Abs(k.GetHashCode()) % capacity;

            // If that particular index is null, then there is no
            // entry for the given key
            // Else search whether an entry exists for that key
            if (myKeyList[index] == null)
                return false;
            
            else
            {
                foreach (MyHashPair<Key, Value> temp in myKeyList[index])
                {
                    // if found, return true
                    if (temp.getKey().Equals(k))
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Iterates through the keys
        /// </summary>
        /// <returns>Key
        /// </returns>
        public IEnumerator<Key> GetEnumerator()
        {
            // Iterate through the keys
            for (int i = 0; i < capacity; i++)
            {
                if (myKeyList[i] != null)
                {
                    foreach (MyHashPair<Key, Value> temp in myKeyList[i])
                    {
                        yield return temp.getKey();
                    }
                }
            }
        }

        /// <summary>
        /// Returns an enumerator
        /// </summary>
        /// <returns>GetEnumerator()
        /// </returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

    }

    /// <summary>
    /// Contains the test cases
    /// </summary>
    public class TestTable
    {

        /// <summary>
        /// Contains all the test cases.
        /// </summary>
        public static void test()
        {
            test1();
            test2();
            test3();
            test4();
        }

        // Test Case 1 to check insertion of keys
        public static void test1()
        {

            bool flag = true;
            Console.WriteLine("Executing Test 1: ");
            System.Diagnostics.Stopwatch sw1 = new System.Diagnostics.Stopwatch();
            sw1.Start();
            Table<String, int> test1 = TableFactory.Make<String, int>(10, .5);
            for (int i = 0; i < 1000; i++)
            {
                test1.Put(i + "", i);
            }

            for (int i = 0; i < 1000; i++)
            {
                if (!test1.Contains(i + ""))
                {
                    flag = false;
                    sw1.Stop();
                    Console.WriteLine("Test 1 Failed");
                    Console.Write("Time:" + sw1.Elapsed);
                    break;
                }
            }

            if (flag)
            {
                Console.WriteLine("Test 1 Result: Passed");
                sw1.Stop();
                Console.WriteLine("Test 1 Time: " + sw1.Elapsed);
            }
        }

        // Test Case 2 to check assignment of values to keys
        public static void test2()
        {

            bool flag = true;
            Console.WriteLine("Executing Test 2: ");
            System.Diagnostics.Stopwatch sw2 = new System.Diagnostics.Stopwatch();
            sw2.Start();

            Table<String, int> test2 = TableFactory.Make<String, int>(10, .5);
            for (int i = 0; i < 5555; i++)
            {
                test2.Put(i + "", i);
            }

            for (int i = 0; i < 5555; i++)
            {
                if (!test2.Get(i + "").Equals(i))
                {
                    flag = false;
                    Console.WriteLine("Test 2 Result: Failed");
                    sw2.Stop();
                    Console.WriteLine("Test 2 Time: " + sw2.Elapsed);
                    break;
                }
            }

            if (flag)
            {
                Console.WriteLine("Test 2 Result: Passed");
                sw2.Stop();
                Console.WriteLine("Test 2 Time: " + sw2.Elapsed);
            }
        }

        // Test Case 3 to check entry of 100K items
        public static void test3()
        {


            Console.WriteLine("Executing Test 3: ");
            System.Diagnostics.Stopwatch sw3 = new System.Diagnostics.Stopwatch();
            sw3.Start();
            Table<String, int> test3 = TableFactory.Make<String, int>(10, .5);
            for (int i = 0; i < 100000; i++)
            {
                test3.Put(i + "", i);
            }
            sw3.Stop();
            Console.WriteLine("Test 3 Result: Passed");
            Console.WriteLine("Test 3: Time required by 100K items: " + sw3.Elapsed);

        }

        // Test Case 4 to check basic enumerator functionality
        public static void test4()
        {

            Console.WriteLine("Executing Test 4: ");
            System.Diagnostics.Stopwatch sw4 = new System.Diagnostics.Stopwatch();
            sw4.Start();
            Table<String, int> test4 = TableFactory.Make<String, int>(10, .5);
            for (int i = 0; i < 100; i++)
            {
                test4.Put(i + "", i);
            }
            // bool flag = false;
            int counter = 0;
            System.Collections.IEnumerator e = test4.GetEnumerator();


            while (e.MoveNext())
            {
                // flag = true;
                counter++;
            }

            sw4.Stop();
            Console.WriteLine("Test 4 Result: Passed");
            Console.WriteLine("Test 4 : Time required to enumerate " + counter + " items: " + sw4.Elapsed);
        }
    }
}