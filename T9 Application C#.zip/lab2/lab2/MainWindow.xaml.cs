﻿/** 
 * MainWindow.xaml.cs
 * @author Parth Sawant pss7278
 * */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Controller ctrl = new Controller();
        Button tmp = new Button();

        /// <summary>
        /// Constructor for initialization of default values
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Event call to handle all button clicks
        /// </summary>
        /// <param name="sender">Function Caller</param>
        /// <param name="e">Sender details</param>
        void btClick(object sender, RoutedEventArgs e)
        {
            //Casting into a Button object to get some Button data
            tmp = (Button)e.Source;
            string feed = "";

            //Using a switch case statement to disassociate the UI and the lookup values for the dictionary
            switch (tmp.Tag.ToString())
            {
                case "1":
                    feed = "1";
                    break;
                case "2":
                    feed = "2 abc";
                    break;
                case "3":
                    feed = "3 def";
                    break;
                case "4":
                    feed = "4 ghi";
                    break;
                case "5":
                    feed = "5 jkl";
                    break;
                case "6":
                    feed = "6 mno";
                    break;
                case "7":
                    feed = "7 pqrs";
                    break;
                case "8":
                    feed = "8 tuv";
                    break;
                case "9":
                    feed = "9 wxyz";
                    break;
                case "10":
                    feed = "* &lt;";
                    break;
                case "11":
                    feed = "0 ~";
                    break;
                case "12":
                    feed = "#";
                    break;
                default:
                    break;

            }

            //calling controller to return a string to display according to the provided data.
            Display.Text = ctrl.clickEvent(tmp.Name, feed, ctrl.getPredictMode, Display.Text);

        }

        /// <summary>
        /// Funtion to handle toggling between prediction modes
        /// </summary>
        /// <param name="sender">Function caller</param>
        /// <param name="e">Sender details</param>
        private void t9Click(object sender, RoutedEventArgs e)
        {
            //toggling prediction mode
            ctrl.togglePredictMode();
            if (ctrl.getPredictMode)
            {
                t9.Background = new SolidColorBrush(Colors.Gold);
                t9.Foreground = new SolidColorBrush(Colors.Black);
            }
            else
            {
                t9.Background = new SolidColorBrush(Colors.Black);
                t9.Foreground = new SolidColorBrush(Colors.Gold);
            }
        }
    }
}
