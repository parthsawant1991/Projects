﻿/**
 * Controller.cs
 * @author Parth Sawant pss7278
 * */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace lab2
{
    class Controller
    {

        private Model model; //Model object
        private bool predict; //Prediction flag
        private string last; //Last button clicked
        private int index; //Index of current
        private int counter; //Counter for clicks
        private Stopwatch s; //Stopwatch for click timings
        private Stack<string> ipStack; //Stack containing values of clicked buttons
        private string[] words; //List of valid words
        private string prev; //Previously entered text



        /// <summary>
        /// Constructor to initialize controller.
        /// </summary>
        public Controller()
        {
            model = new Model();
            predict = false;
            last = "";
            index = 1;
            counter = 0;
            ipStack = new Stack<string>();
            prev = "";
            s = new Stopwatch();
            s.Start();

        }

        /// <summary>
        /// Returns the prediction mode
        /// </summary>
        public bool getPredictMode
        {
            get
            {
                return predict;
            }
        }

        /// <summary>
        /// Toggles prediction mode
        /// </summary>
        public void togglePredictMode()
        {
            predict = !predict;
        }


        public string clickEvent(string btName, string feed, bool predict, string input)
        {
            string text = ""; //Returned to the Display.text

            //When predictive mode OFF
            if (!predict)
            {

                //stopping timer
                s.Stop();

                //When alphabet buttons are pressed
                if (!btName.Equals("bt10") && !btName.Equals("bt11") && !btName.Equals("bt12"))
                {
                    //Checks whether the last button is the same as this button and within 500ms 
                    //(500 ms is the default value for double clicks according to Microsoft standards in MSDN) 
                    if (btName.Equals(last) && s.ElapsedMilliseconds < 500)
                    {
                        counter++;

                        //When 4 alphabet buttons are clicked
                        if (btName.Equals("bt7") || btName.Equals("bt9"))
                        {
                            text = feed.Substring((counter % 4) + 2, 1);
                        }
                        //When 3 alphabet buttons are clicked
                        else
                        {
                            text = feed.Substring((counter % 3) + 2, 1);
                        }

                        text = input.Substring(0, input.Length - 1) + text;
                    }
                    else
                    {
                        //Saves the last button clicked for next iteration
                        last = btName;

                        //Reset counter
                        counter = 0;

                        text = input + feed.Substring(counter + 2, 1);
                    }
                }

                else if (btName.Equals("bt10"))
                {
                    if (input.Length > 0)
                        text = input.Substring(0, input.Length - 1);
                }

                else if (btName.Equals("bt12"))
                {
                    text = input + " ";
                }

                else
                {
                    text = input;
                }
                s.Reset();
                s.Start();
                return text;
            }

            //Predictive mode ON
            else
            {
                //Checking all values in the list
                if (btName.Equals("bt11"))
                {
                    if (words != null && words.Length > 0)
                    {
                        if (index < words.Length)
                            text = prev + words[index++];
                        else
                        {
                            index = 0;
                            text = prev + words[index++];
                        }
                    }
                }

                //Reset the values for a new word entry
                else if (btName.Equals("bt12"))
                {
                    ipStack = new Stack<string>();
                    words = null;
                    text = input + " ";
                    prev = text;
                }

                //Remove the last entered character
                else if (btName.Equals("bt10"))
                {
                    if (ipStack.Count > 0)
                    {
                        ipStack.Pop();
                        if (ipStack.Count > 0)
                        {
                            words = model.getWordlist(ipStack, input).ToArray();
                            index = 1;
                            if (prev == "")
                                text = words[0];
                            else
                                text = prev + words[0];
                        }
                        else
                        {
                            text = prev;
                            words = null;
                        }
                    }
                    else
                    {
                        if (prev.Length > 0)
                        {
                            string deleteLast = prev.Substring(0, prev.Length - 1);
                            string[] deleteLastSplit = deleteLast.Split(' ');
                            int len = deleteLastSplit[deleteLastSplit.Length - 1].Length;
                            prev = prev.Substring(0, prev.Length - len - 1);
                            text = prev;
                        }
                    }
                }
                else
                {

                    if (ipStack.Count == 0 && input.Length > 0)
                        prev = input;
                    //Push new character on user click
                    ipStack.Push(feed.Substring(0, 1));
                    //Get the list of all possible words.
                    words = model.getWordlist(ipStack, input).ToArray();
                    index = 1;
                    if (prev == "")
                    {
                        text = words[0];
                    }
                    else
                    {
                        text = prev + words[0];
                    }
                }
                return text;
            }
        }
    }
}