﻿/**
 * Model.cs
 * @author Parth Sawant pss7278
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows;

namespace lab2
{
    class Model
    {
        Dictionary<string, string> myDictionary;
        System.IO.StreamReader sr;

        public Model()
        {
            myDictionary = new Dictionary<string, string>();
            getWords();

        }

        public void getWords()
        {
            //Creates a temporary dictionary object to store all alphabets
            Dictionary<char, int> tmpDict = new Dictionary<char, int>();

            tmpDict.Add('a', 2);
            tmpDict.Add('b', 2);
            tmpDict.Add('c', 2);
            tmpDict.Add('d', 3);
            tmpDict.Add('e', 3);
            tmpDict.Add('f', 3);
            tmpDict.Add('g', 4);
            tmpDict.Add('h', 4);
            tmpDict.Add('i', 4);
            tmpDict.Add('j', 5);
            tmpDict.Add('k', 5);
            tmpDict.Add('l', 5);
            tmpDict.Add('m', 6);
            tmpDict.Add('n', 6);
            tmpDict.Add('o', 6);
            tmpDict.Add('p', 7);
            tmpDict.Add('q', 7);
            tmpDict.Add('r', 7);
            tmpDict.Add('s', 7);
            tmpDict.Add('t', 8);
            tmpDict.Add('u', 8);
            tmpDict.Add('v', 8);
            tmpDict.Add('w', 9);
            tmpDict.Add('x', 9);
            tmpDict.Add('y', 9);
            tmpDict.Add('z', 9);

            try
            {
                sr = new System.IO.StreamReader("english-words.txt");
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Dictionary file not found.");
                return;
            }

            string line;
            string chars;

            //Parsing the dictionary provided
            while ((line = sr.ReadLine()) != null)
            {
                chars = "";
                for (int i = 0; i < line.Length; i++)
                {
                    chars = chars + tmpDict[line[i]].ToString();
                }
                myDictionary.Add(line, chars);
            }
        }


        /// <summary>
        /// Generate a list of words according to the input
        /// </summary>
        /// <param name="letters">Letters entered by the user</param>
        /// <param name="input">Current content of the textbox</param>
        /// <returns>List of matching words from the dictionary</returns>
        public List<string> getWordlist(Stack<string> letters, string input)
        {
            //Stack copy to maintain consistency and integrity of original stack
            Stack<string> copyStack = new Stack<string>(letters);

            //List of possible valid words
            List<string> validList = new List<string>();
            string words = "";
            while (copyStack.Count > 0)
            {
                words = words + copyStack.Pop();
            }

            var validWords = from keyvalPair in myDictionary
                             where keyvalPair.Value.Equals(words)
                             select keyvalPair.Key;

            validList.AddRange(validWords);

            //If no words of the given length are available, showing words with prefix
            if (validList.Count == 0)
            {
                var prefixWords = from keyvalPair in myDictionary
                                  where keyvalPair.Value.StartsWith(words)
                                  select keyvalPair.Key;

                validList.AddRange(prefixWords);
            }

            //If no words with a valid prefix are found, show  '-' for each letter entered
            if (validList.Count == 0)
            {
                string s = "";
                validList.Add(s.PadRight(letters.Count, '-'));
            }
            return validList;
        }
    }
}
